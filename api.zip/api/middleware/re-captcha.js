let axios = require('axios')

module.exports = recaptcha = async (req, res, next) => {
    let captchaResponse = req.body.captchaResponse

    try {
        const response = await axios.post('https://www.google.com/recaptcha/api/siteverify', null, {
            params: {
                secret: process.env.CLAVE_PRIVATE,
                response: captchaResponse,
            },
        });
        if (response.data.success) {
            next()
        } else {
            res.status(400).send({ message: 'Token inválido, inténtelo mas tarde' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).send({ message: 'Error interno del servidor, inténtelo mas tarde' });
    }

}

