const pgp = require('pg-promise')(/* options */)
require('dotenv').config({ path: './.env' })

const db = pgp(`postgres://${process.env.usuario}:${process.env.passwd}@${process.env.ip}/${process.env.db}`)
module.exports = db