var router = require("express").Router();
const usuario = require("./usuario")
router.use('/usuario',usuario)
module.exports = router