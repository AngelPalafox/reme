const user = require("../controller/usuario");
const recaptcha = require('../middleware/re-captcha')
var router = require("express").Router();

router.post("/login", recaptcha, user.login);
router.post("/create", recaptcha, user.create);
router.post("/codigo_verificacion", user.codigoVerificacion);

module.exports = router
